export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      user_habits: {
        Row: {
          id: string
          user_id: string
          habit_id: string
          name: string
          description: string
          category: 'energy' | 'transport' | 'waste' | 'water' | 'food' | 'lifestyle'
          points: number
          icon: string
          is_selected: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          habit_id: string
          name: string
          description: string
          category: 'energy' | 'transport' | 'waste' | 'water' | 'food' | 'lifestyle'
          points: number
          icon: string
          is_selected?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          habit_id?: string
          name?: string
          description?: string
          category?: 'energy' | 'transport' | 'waste' | 'water' | 'food' | 'lifestyle'
          points?: number
          icon?: string
          is_selected?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      habit_completions: {
        Row: {
          id: string
          user_id: string
          habit_id: string
          completed_date: string
          points_earned: number
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          habit_id: string
          completed_date: string
          points_earned: number
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          habit_id?: string
          completed_date?: string
          points_earned?: number
          created_at?: string
        }
      }
      user_progress: {
        Row: {
          id: string
          user_id: string
          total_points: number
          current_streak: number
          best_streak: number
          level: number
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          total_points?: number
          current_streak?: number
          best_streak?: number
          level?: number
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          total_points?: number
          current_streak?: number
          best_streak?: number
          level?: number
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}