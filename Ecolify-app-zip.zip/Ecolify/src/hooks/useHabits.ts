import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { UserHabit, UserProgress } from '../types/habits';
import { defaultHabits } from '../data/defaultHabits';
import { useAuth } from './useAuth';

export const useHabits = () => {
  const { user } = useAuth();
  const [habits, setHabits] = useState<UserHabit[]>([]);
  const [progress, setProgress] = useState<UserProgress>({
    totalPoints: 0,
    currentStreak: 0,
    bestStreak: 0,
    level: 1,
    dailyProgress: [],
    habits: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadUserData();
    } else {
      setLoading(false);
    }
  }, [user]);

  const loadUserData = async () => {
    if (!user) return;

    try {
      setLoading(true);

      // Load user habits
      const { data: userHabits, error: habitsError } = await supabase
        .from('user_habits')
        .select('*')
        .eq('user_id', user.id);

      if (habitsError) throw habitsError;

      // If no habits exist, create default ones
      if (!userHabits || userHabits.length === 0) {
        await initializeDefaultHabits();
        return;
      }

      // Load habit completions
      const { data: completions, error: completionsError } = await supabase
        .from('habit_completions')
        .select('*')
        .eq('user_id', user.id);

      if (completionsError) throw completionsError;

      // Load user progress
      const { data: userProgress, error: progressError } = await supabase
        .from('user_progress')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (progressError && progressError.code !== 'PGRST116') throw progressError;

      // Transform data to match our types
      const transformedHabits: UserHabit[] = userHabits.map(habit => {
        const habitCompletions = completions?.filter(c => c.habit_id === habit.habit_id) || [];
        const completedDates = habitCompletions.map(c => c.completed_date);
        const currentStreak = calculateStreak(completedDates);
        const bestStreak = calculateBestStreak(completedDates);

        return {
          id: habit.habit_id,
          name: habit.name,
          description: habit.description,
          category: habit.category,
          points: habit.points,
          icon: habit.icon,
          isSelected: habit.is_selected,
          completedDates,
          currentStreak,
          bestStreak
        };
      });

      // Calculate daily progress
      const dailyProgress = calculateDailyProgress(transformedHabits);

      const progressData: UserProgress = {
        totalPoints: userProgress?.total_points || 0,
        currentStreak: userProgress?.current_streak || 0,
        bestStreak: userProgress?.best_streak || 0,
        level: userProgress?.level || 1,
        dailyProgress,
        habits: transformedHabits
      };

      setHabits(transformedHabits);
      setProgress(progressData);
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  };

  const initializeDefaultHabits = async () => {
    if (!user) return;

    try {
      const habitsToInsert = defaultHabits.map(habit => ({
        user_id: user.id,
        habit_id: habit.id,
        name: habit.name,
        description: habit.description,
        category: habit.category,
        points: habit.points,
        icon: habit.icon,
        is_selected: false
      }));

      const { error } = await supabase
        .from('user_habits')
        .insert(habitsToInsert);

      if (error) throw error;

      // Initialize user progress
      const { error: progressError } = await supabase
        .from('user_progress')
        .insert({
          user_id: user.id,
          total_points: 0,
          current_streak: 0,
          best_streak: 0,
          level: 1
        });

      if (progressError) throw progressError;

      // Reload data
      await loadUserData();
    } catch (error) {
      console.error('Error initializing default habits:', error);
    }
  };

  const toggleHabitSelection = async (habitId: string) => {
    if (!user) return;

    try {
      const habit = habits.find(h => h.id === habitId);
      if (!habit) return;

      const { error } = await supabase
        .from('user_habits')
        .update({ is_selected: !habit.isSelected })
        .eq('user_id', user.id)
        .eq('habit_id', habitId);

      if (error) throw error;

      // Update local state
      setHabits(prev => prev.map(h => 
        h.id === habitId ? { ...h, isSelected: !h.isSelected } : h
      ));
    } catch (error) {
      console.error('Error toggling habit selection:', error);
    }
  };

  const toggleHabitCompletion = async (habitId: string) => {
    if (!user) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      const habit = habits.find(h => h.id === habitId);
      if (!habit) return;

      const isCompleted = habit.completedDates.includes(today);

      if (isCompleted) {
        // Remove completion
        const { error } = await supabase
          .from('habit_completions')
          .delete()
          .eq('user_id', user.id)
          .eq('habit_id', habitId)
          .eq('completed_date', today);

        if (error) throw error;
      } else {
        // Add completion
        const { error } = await supabase
          .from('habit_completions')
          .insert({
            user_id: user.id,
            habit_id: habitId,
            completed_date: today,
            points_earned: habit.points
          });

        if (error) throw error;
      }

      // Reload data to recalculate everything
      await loadUserData();
    } catch (error) {
      console.error('Error toggling habit completion:', error);
    }
  };

  return {
    habits,
    progress,
    loading,
    toggleHabitSelection,
    toggleHabitCompletion,
    refreshData: loadUserData
  };
};

// Helper functions
const calculateStreak = (completedDates: string[]): number => {
  if (completedDates.length === 0) return 0;
  
  const sortedDates = completedDates.sort().reverse();
  const today = new Date().toISOString().split('T')[0];
  
  let streak = 0;
  let currentDate = new Date(today);
  
  for (const dateString of sortedDates) {
    const date = new Date(dateString);
    const diffTime = currentDate.getTime() - date.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === streak) {
      streak++;
      currentDate = new Date(date);
    } else {
      break;
    }
  }
  
  return streak;
};

const calculateBestStreak = (completedDates: string[]): number => {
  if (completedDates.length === 0) return 0;
  
  const sortedDates = completedDates.sort();
  let bestStreak = 0;
  let currentStreak = 1;
  
  for (let i = 1; i < sortedDates.length; i++) {
    const prevDate = new Date(sortedDates[i - 1]);
    const currentDate = new Date(sortedDates[i]);
    const diffTime = currentDate.getTime() - prevDate.getTime();
    const diffDays = diffTime / (1000 * 60 * 60 * 24);
    
    if (diffDays === 1) {
      currentStreak++;
    } else {
      bestStreak = Math.max(bestStreak, currentStreak);
      currentStreak = 1;
    }
  }
  
  return Math.max(bestStreak, currentStreak);
};

const calculateDailyProgress = (habits: UserHabit[]) => {
  const dailyProgress: any[] = [];
  const selectedHabits = habits.filter(h => h.isSelected);
  
  if (selectedHabits.length === 0) return dailyProgress;
  
  // Get all unique dates
  const allDates = new Set<string>();
  selectedHabits.forEach(habit => {
    habit.completedDates.forEach(date => allDates.add(date));
  });
  
  // Calculate progress for each date
  Array.from(allDates).sort().forEach(date => {
    const completedHabits = selectedHabits.filter(h => h.completedDates.includes(date));
    const totalPoints = completedHabits.reduce((sum, h) => sum + h.points, 0);
    const completionRate = (completedHabits.length / selectedHabits.length) * 100;
    
    dailyProgress.push({
      date,
      completedHabits: completedHabits.map(h => h.id),
      totalPoints,
      completionRate
    });
  });
  
  return dailyProgress;
};