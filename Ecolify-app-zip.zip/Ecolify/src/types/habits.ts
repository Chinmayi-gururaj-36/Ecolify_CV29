export interface Habit {
  id: string;
  name: string;
  description: string;
  category: 'energy' | 'transport' | 'waste' | 'water' | 'food' | 'lifestyle';
  points: number;
  icon: string;
}

export interface UserHabit extends Habit {
  isSelected: boolean;
  completedDates: string[];
  currentStreak: number;
  bestStreak: number;
}

export interface DailyProgress {
  date: string;
  completedHabits: string[];
  totalPoints: number;
  completionRate: number;
}

export interface UserProgress {
  totalPoints: number;
  currentStreak: number;
  bestStreak: number;
  level: number;
  dailyProgress: DailyProgress[];
  habits: UserHabit[];
}