import React from 'react';
import { UserHabit } from '../types/habits';
import { getTodayString } from '../utils/storage';
import * as Icons from 'lucide-react';

interface DailyTrackerProps {
  habits: UserHabit[];
  onToggleCompletion: (habitId: string) => void;
}

export const DailyTracker: React.FC<DailyTrackerProps> = ({ habits, onToggleCompletion }) => {
  const today = getTodayString();
  const selectedHabits = habits.filter(habit => habit.isSelected);
  const completedToday = selectedHabits.filter(habit => habit.completedDates.includes(today));
  const completionRate = selectedHabits.length > 0 ? (completedToday.length / selectedHabits.length) * 100 : 0;

  const getIcon = (iconName: string) => {
    const IconComponent = Icons[iconName as keyof typeof Icons] as React.ComponentType<any>;
    return IconComponent ? <IconComponent size={20} /> : <Icons.Circle size={20} />;
  };

  if (selectedHabits.length === 0) {
    return (
      <div className="text-center py-12">
        <Icons.Leaf size={48} className="mx-auto text-gray-400 mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No habits selected</h3>
        <p className="text-gray-600">Choose some green habits to start tracking your progress!</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Daily Progress Header */}
      <div className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold mb-1">Today's Progress</h2>
            <p className="text-green-100">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">{completedToday.length}/{selectedHabits.length}</div>
            <div className="text-sm text-green-100">habits completed</div>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="bg-green-400 bg-opacity-30 rounded-full h-3 overflow-hidden">
          <div 
            className="bg-white h-full transition-all duration-500 ease-out"
            style={{ width: `${completionRate}%` }}
          />
        </div>
        <div className="text-right mt-2 text-sm text-green-100">
          {Math.round(completionRate)}% complete
        </div>
      </div>

      {/* Habits List */}
      <div className="space-y-3">
        {selectedHabits.map((habit) => {
          const isCompleted = habit.completedDates.includes(today);
          
          return (
            <div
              key={habit.id}
              className={`p-4 rounded-lg border transition-all duration-200 cursor-pointer hover:shadow-md ${
                isCompleted
                  ? 'bg-green-50 border-green-200 shadow-sm'
                  : 'bg-white border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => onToggleCompletion(habit.id)}
            >
              <div className="flex items-center space-x-4">
                {/* Checkbox */}
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
                  isCompleted 
                    ? 'bg-green-500 border-green-500' 
                    : 'border-gray-300 hover:border-green-400'
                }`}>
                  {isCompleted && <Icons.Check size={16} className="text-white" />}
                </div>

                {/* Habit Icon */}
                <div className={`p-2 rounded-full ${isCompleted ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-600'}`}>
                  {getIcon(habit.icon)}
                </div>

                {/* Habit Details */}
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <h3 className={`font-medium ${isCompleted ? 'text-green-900' : 'text-gray-900'}`}>
                      {habit.name}
                    </h3>
                    <div className="flex items-center space-x-3">
                      {habit.currentStreak > 0 && (
                        <div className="flex items-center space-x-1 text-orange-600">
                          <Icons.Flame size={16} />
                          <span className="text-sm font-medium">{habit.currentStreak}</span>
                        </div>
                      )}
                      <div className="flex items-center space-x-1 text-amber-600">
                        <Icons.Star size={16} fill="currentColor" />
                        <span className="text-sm font-medium">{habit.points}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600">{habit.description}</p>
                </div>
              </div>
              
              {isCompleted && (
                <div className="mt-3 ml-10 flex items-center space-x-2 text-green-600 animate-fade-in">
                  <Icons.CheckCircle size={16} />
                  <span className="text-sm font-medium">Completed today! Great job!</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};