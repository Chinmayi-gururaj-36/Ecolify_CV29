import React, { useRef, useEffect } from 'react';
import { UserProgress } from '../types/habits';
import * as Icons from 'lucide-react';

interface BadgeGeneratorProps {
  progress: UserProgress;
  onDownload: () => void;
}

export const BadgeGenerator: React.FC<BadgeGeneratorProps> = ({ progress, onDownload }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    generateBadge();
  }, [progress]);

  const generateBadge = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = 400;
    const height = 500;
    canvas.width = width;
    canvas.height = height;

    // Background gradient
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#10b981');
    gradient.addColorStop(1, '#059669');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Badge border
    ctx.strokeStyle = '#34d399';
    ctx.lineWidth = 4;
    ctx.strokeRect(20, 20, width - 40, height - 40);

    // Title
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 28px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('GREEN HERO', width / 2, 80);
    ctx.fillText('CERTIFICATE', width / 2, 115);

    // Decorative elements
    ctx.fillStyle = '#34d399';
    ctx.font = '40px Arial';
    ctx.fillText('🌱', width / 2, 160);

    // Stats
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 18px Arial';
    ctx.fillText(`Level ${progress.level} Eco Warrior`, width / 2, 200);

    ctx.font = '16px Arial';
    ctx.fillText(`Total Points: ${progress.totalPoints}`, width / 2, 240);
    ctx.fillText(`Best Streak: ${progress.bestStreak} days`, width / 2, 270);
    ctx.fillText(`Habits Completed: ${progress.dailyProgress.length}`, width / 2, 300);

    // Achievement message
    ctx.font = 'italic 14px Arial';
    ctx.fillStyle = '#d1fae5';
    ctx.fillText('For outstanding commitment to', width / 2, 350);
    ctx.fillText('environmental sustainability', width / 2, 375);

    // Date
    ctx.font = '12px Arial';
    ctx.fillText(`Awarded on ${new Date().toLocaleDateString()}`, width / 2, 420);

    // Footer
    ctx.fillStyle = '#34d399';
    ctx.font = 'bold 14px Arial';
    ctx.fillText('🌍 Powered by Ecolify 🌍', width / 2, 460);
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `ecolify-green-hero-certificate-level-${progress.level}.png`;
    link.href = canvas.toDataURL();
    link.click();
    onDownload();
  };

  const getBadgeTitle = () => {
    if (progress.level >= 10) return 'Eco Champion';
    if (progress.level >= 7) return 'Green Guardian';
    if (progress.level >= 5) return 'Earth Defender';
    if (progress.level >= 3) return 'Eco Warrior';
    return 'Green Hero';
  };

  const canDownload = progress.totalPoints >= 50 || progress.bestStreak >= 7;

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Your Green Hero Badge</h2>
        <p className="text-gray-600">
          {canDownload 
            ? 'Congratulations! You\'ve earned your certificate!' 
            : 'Complete more habits to unlock your certificate'
          }
        </p>
      </div>

      {/* Badge Preview */}
      <div className="bg-white rounded-xl p-8 border border-gray-200 shadow-lg">
        <div className="max-w-md mx-auto">
          {/* Preview Badge */}
          <div className="bg-gradient-to-b from-green-500 to-emerald-600 rounded-lg p-8 text-white text-center shadow-lg">
            <div className="border-4 border-green-300 rounded-lg p-6">
              <div className="text-3xl mb-2">🏆</div>
              <h3 className="text-xl font-bold mb-2">GREEN HERO</h3>
              <h4 className="text-lg mb-4">CERTIFICATE</h4>
              
              <div className="text-4xl mb-4">🌱</div>
              
              <div className="space-y-2 mb-4">
                <p className="font-semibold">{getBadgeTitle()}</p>
                <p className="text-sm">Level {progress.level}</p>
              </div>
              
              <div className="text-sm space-y-1 mb-4 text-green-100">
                <p>Total Points: {progress.totalPoints}</p>
                <p>Best Streak: {progress.bestStreak} days</p>
                <p>Habits Tracking: {progress.habits.filter(h => h.isSelected).length}</p>
              </div>
              
              <div className="text-xs italic text-green-200 mb-4">
                <p>For outstanding commitment to</p>
                <p>environmental sustainability</p>
              </div>
              
              <p className="text-xs">Awarded on {new Date().toLocaleDateString()}</p>
            </div>
          </div>

          {/* Download Section */}
          <div className="mt-8 text-center">
            {canDownload ? (
              <button
                onClick={handleDownload}
                className="bg-green-600 hover:bg-green-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 flex items-center space-x-2 mx-auto"
              >
                <Icons.Download size={20} />
                <span>Download Certificate</span>
              </button>
            ) : (
              <div className="space-y-4">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 text-amber-800">
                    <Icons.Lock size={20} />
                    <span className="font-medium">Certificate Locked</span>
                  </div>
                  <p className="text-sm text-amber-700 mt-2">
                    {progress.totalPoints < 50 
                      ? `Earn ${50 - progress.totalPoints} more points to unlock`
                      : `Maintain a ${7 - progress.bestStreak} day streak to unlock`
                    }
                  </p>
                </div>
                
                <div className="bg-gray-100 rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-2">How to unlock:</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Reach 50 total points OR</li>
                    <li>• Maintain a 7-day streak</li>
                    <li>• Keep tracking your daily habits</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Hidden canvas for actual certificate generation */}
      <canvas 
        ref={canvasRef} 
        style={{ display: 'none' }}
        width={400} 
        height={500}
      />
    </div>
  );
};