import React from 'react';
import { UserHabit } from '../types/habits';
import * as Icons from 'lucide-react';

interface HabitSelectorProps {
  habits: UserHabit[];
  onToggleHabit: (habitId: string) => void;
}

const categoryColors = {
  energy: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  transport: 'bg-blue-100 text-blue-800 border-blue-200',
  waste: 'bg-purple-100 text-purple-800 border-purple-200',
  water: 'bg-cyan-100 text-cyan-800 border-cyan-200',
  food: 'bg-green-100 text-green-800 border-green-200',
  lifestyle: 'bg-pink-100 text-pink-800 border-pink-200'
};

const categoryNames = {
  energy: 'Energy',
  transport: 'Transport',
  waste: 'Waste',
  water: 'Water',
  food: 'Food',
  lifestyle: 'Lifestyle'
};

export const HabitSelector: React.FC<HabitSelectorProps> = ({ habits, onToggleHabit }) => {
  const categorizedHabits = habits.reduce((acc, habit) => {
    if (!acc[habit.category]) {
      acc[habit.category] = [];
    }
    acc[habit.category].push(habit);
    return acc;
  }, {} as Record<string, UserHabit[]>);

  const getIcon = (iconName: string) => {
    const IconComponent = Icons[iconName as keyof typeof Icons] as React.ComponentType<any>;
    return IconComponent ? <IconComponent size={20} /> : <Icons.Circle size={20} />;
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Choose Your Green Habits</h2>
        <p className="text-gray-600">Select the eco-friendly habits you want to track daily</p>
      </div>

      {Object.entries(categorizedHabits).map(([category, categoryHabits]) => (
        <div key={category} className="space-y-4">
          <div className="flex items-center space-x-2">
            <span className={`px-3 py-1 rounded-full text-sm font-medium border ${categoryColors[category as keyof typeof categoryColors]}`}>
              {categoryNames[category as keyof typeof categoryNames]}
            </span>
          </div>
          
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {categoryHabits.map((habit) => (
              <div
                key={habit.id}
                className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-200 hover:shadow-md ${
                  habit.isSelected
                    ? 'border-green-500 bg-green-50 shadow-sm'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
                onClick={() => onToggleHabit(habit.id)}
              >
                <div className="flex items-start space-x-3">
                  <div className={`p-2 rounded-full ${habit.isSelected ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-600'}`}>
                    {getIcon(habit.icon)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-medium text-gray-900 text-sm leading-tight">{habit.name}</h3>
                      <div className="flex items-center space-x-1 text-amber-600">
                        <Icons.Star size={14} fill="currentColor" />
                        <span className="text-xs font-medium">{habit.points}</span>
                      </div>
                    </div>
                    <p className="text-xs text-gray-600 leading-relaxed">{habit.description}</p>
                    {habit.currentStreak > 0 && (
                      <div className="mt-2 flex items-center space-x-1 text-green-600">
                        <Icons.Flame size={12} />
                        <span className="text-xs font-medium">{habit.currentStreak} day streak</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};