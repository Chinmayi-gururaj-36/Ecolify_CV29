import React from 'react';
import { UserProgress } from '../types/habits';
import { getPointsForNextLevel } from '../utils/storage';
import * as Icons from 'lucide-react';

interface ProgressStatsProps {
  progress: UserProgress;
}

export const ProgressStats: React.FC<ProgressStatsProps> = ({ progress }) => {
  const pointsForNextLevel = getPointsForNextLevel(progress.totalPoints);
  const levelProgress = ((progress.totalPoints % 100) / 100) * 100;
  
  const stats = [
    {
      label: 'Total Points',
      value: progress.totalPoints,
      icon: 'star',
      color: 'text-amber-600 bg-amber-100'
    },
    {
      label: 'Current Streak',
      value: progress.currentStreak,
      icon: 'flame',
      color: 'text-orange-600 bg-orange-100'
    },
    {
      label: 'Best Streak',
      value: progress.bestStreak,
      icon: 'trophy',
      color: 'text-purple-600 bg-purple-100'
    },
    {
      label: 'Eco Level',
      value: progress.level,
      icon: 'leaf',
      color: 'text-green-600 bg-green-100'
    }
  ];

  const getIcon = (iconName: string) => {
    const IconComponent = Icons[iconName as keyof typeof Icons] as React.ComponentType<any>;
    return IconComponent ? <IconComponent size={24} /> : <Icons.Circle size={24} />;
  };

  return (
    <div className="space-y-6">
      {/* Level Progress */}
      <div className="bg-gradient-to-r from-emerald-500 to-green-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold mb-1">Eco Level {progress.level}</h3>
            <p className="text-emerald-100 text-sm">
              {pointsForNextLevel} points to level {progress.level + 1}
            </p>
          </div>
          <div className="bg-white bg-opacity-20 rounded-full p-3">
            <Icons.TreePine size={28} />
          </div>
        </div>
        
        <div className="bg-emerald-400 bg-opacity-30 rounded-full h-4 overflow-hidden">
          <div 
            className="bg-white h-full transition-all duration-1000 ease-out"
            style={{ width: `${levelProgress}%` }}
          />
        </div>
        <div className="text-right mt-2 text-sm text-emerald-100">
          {Math.round(levelProgress)}% to next level
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <div key={stat.label} className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <div className={`p-2 rounded-full ${stat.color}`}>
                {getIcon(stat.icon)}
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">
              {stat.value.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      {progress.dailyProgress.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
            <Icons.BarChart3 size={20} />
            <span>Recent Activity</span>
          </h3>
          
          <div className="space-y-3">
            {progress.dailyProgress.slice(-7).reverse().map((day, index) => (
              <div key={day.date} className="flex items-center justify-between py-2">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full" />
                  <span className="text-sm text-gray-900">
                    {new Date(day.date).toLocaleDateString('en-US', { 
                      weekday: 'short', 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </span>
                </div>
                <div className="flex items-center space-x-4 text-sm">
                  <span className="text-gray-600">
                    {Math.round(day.completionRate)}% complete
                  </span>
                  <div className="flex items-center space-x-1 text-amber-600">
                    <Icons.Star size={14} fill="currentColor" />
                    <span className="font-medium">{day.totalPoints}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};