import { Habit } from '../types/habits';

export const defaultHabits: Habit[] = [
  // Energy
  {
    id: 'switch-off-lights',
    name: 'Switch off lights when leaving room',
    description: 'Turn off lights when not needed to save energy',
    category: 'energy',
    points: 10,
    icon: 'lightbulb'
  },
  {
    id: 'unplug-devices',
    name: 'Unplug electronic devices',
    description: 'Unplug chargers and devices when not in use',
    category: 'energy',
    points: 15,
    icon: 'plug'
  },
  {
    id: 'natural-light',
    name: 'Use natural light during day',
    description: 'Open curtains and use daylight instead of artificial lighting',
    category: 'energy',
    points: 12,
    icon: 'sun'
  },
  
  // Transport
  {
    id: 'public-transport',
    name: 'Use public transport',
    description: 'Take bus, train, or metro instead of private vehicle',
    category: 'transport',
    points: 25,
    icon: 'bus'
  },
  {
    id: 'walk-bike',
    name: 'Walk or bike for short trips',
    description: 'Choose walking or cycling for trips under 2km',
    category: 'transport',
    points: 20,
    icon: 'bike'
  },
  {
    id: 'carpool',
    name: 'Carpool or rideshare',
    description: 'Share rides with others to reduce emissions',
    category: 'transport',
    points: 18,
    icon: 'users'
  },
  
  // Waste
  {
    id: 'reusable-bottle',
    name: 'Use reusable water bottle',
    description: 'Carry a reusable bottle instead of buying plastic ones',
    category: 'waste',
    points: 15,
    icon: 'bottle'
  },
  {
    id: 'reusable-bags',
    name: 'Use reusable shopping bags',
    description: 'Bring your own bags when shopping',
    category: 'waste',
    points: 12,
    icon: 'shopping-bag'
  },
  {
    id: 'recycle',
    name: 'Recycle properly',
    description: 'Sort and recycle waste according to local guidelines',
    category: 'waste',
    points: 10,
    icon: 'recycle'
  },
  {
    id: 'avoid-single-use',
    name: 'Avoid single-use plastics',
    description: 'Choose alternatives to disposable plastic items',
    category: 'waste',
    points: 18,
    icon: 'trash-2'
  },
  
  // Water
  {
    id: 'shorter-showers',
    name: 'Take shorter showers',
    description: 'Limit shower time to 5 minutes or less',
    category: 'water',
    points: 15,
    icon: 'droplets'
  },
  {
    id: 'fix-leaks',
    name: 'Fix water leaks promptly',
    description: 'Repair dripping taps and running toilets',
    category: 'water',
    points: 20,
    icon: 'wrench'
  },
  {
    id: 'full-loads',
    name: 'Run full loads in washer/dishwasher',
    description: 'Wait for full loads before running appliances',
    category: 'water',
    points: 12,
    icon: 'washing-machine'
  },
  
  // Food
  {
    id: 'reduce-meat',
    name: 'Have one plant-based meal',
    description: 'Choose vegetarian or vegan option for at least one meal',
    category: 'food',
    points: 20,
    icon: 'leaf'
  },
  {
    id: 'local-food',
    name: 'Buy local/seasonal produce',
    description: 'Choose locally grown and seasonal fruits and vegetables',
    category: 'food',
    points: 18,
    icon: 'apple'
  },
  {
    id: 'reduce-food-waste',
    name: 'Minimize food waste',
    description: 'Plan meals and use leftovers to reduce food waste',
    category: 'food',
    points: 15,
    icon: 'chef-hat'
  },
  
  // Lifestyle
  {
    id: 'digital-receipts',
    name: 'Choose digital receipts',
    description: 'Opt for email receipts instead of paper ones',
    category: 'lifestyle',
    points: 8,
    icon: 'smartphone'
  },
  {
    id: 'second-hand',
    name: 'Buy second-hand items',
    description: 'Choose pre-owned items when possible',
    category: 'lifestyle',
    points: 22,
    icon: 'shirt'
  },
  {
    id: 'mindful-consumption',
    name: 'Practice mindful consumption',
    description: 'Think twice before buying non-essential items',
    category: 'lifestyle',
    points: 25,
    icon: 'heart'
  }
];