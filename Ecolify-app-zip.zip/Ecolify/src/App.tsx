import React, { useState, useEffect } from 'react';
import { useAuth } from './hooks/useAuth';
import { useHabits } from './hooks/useHabits';
import { AuthForm } from './components/AuthForm';
import { HabitSelector } from './components/HabitSelector';
import { DailyTracker } from './components/DailyTracker';
import { ProgressStats } from './components/ProgressStats';
import { BadgeGenerator } from './components/BadgeGenerator';
import * as Icons from 'lucide-react';

type Tab = 'habits' | 'tracker' | 'progress' | 'badge';

function App() {
  const { user, loading: authLoading, signOut } = useAuth();
  const { habits, progress, loading: habitsLoading, toggleHabitSelection, toggleHabitCompletion } = useHabits();
  const [activeTab, setActiveTab] = useState<Tab>('tracker');
  const [showCelebration, setShowCelebration] = useState(false);

  // Show loading screen while checking authentication
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Icons.Loader2 size={48} className="animate-spin text-green-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading Ecolify...</p>
        </div>
      </div>
    );
  }

  // Show auth form if not authenticated
  if (!user) {
    return <AuthForm />;
  }

  const handleBadgeDownload = () => {
    setShowCelebration(true);
    setTimeout(() => setShowCelebration(false), 3000);
  };

  const tabs = [
    { id: 'tracker' as Tab, label: 'Daily Tracker', icon: 'check-circle' },
    { id: 'habits' as Tab, label: 'Manage Habits', icon: 'settings' },
    { id: 'progress' as Tab, label: 'Progress', icon: 'bar-chart-3' },
    { id: 'badge' as Tab, label: 'Badge', icon: 'award' }
  ];

  const getIcon = (iconName: string) => {
    const IconComponent = Icons[iconName as keyof typeof Icons] as React.ComponentType<any>;
    return IconComponent ? <IconComponent size={20} /> : <Icons.Circle size={20} />;
  };

  const getTodayString = () => new Date().toISOString().split('T')[0];
  const selectedHabitsCount = habits.filter(h => h.isSelected).length;
  const todayCompleted = habits.filter(h => 
    h.isSelected && h.completedDates.includes(getTodayString())
  ).length;

  // Show loading screen while loading habits
  if (habitsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Icons.Loader2 size={48} className="animate-spin text-green-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading your habits...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Celebration Animation */}
      {showCelebration && (
        <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none">
          <div className="bg-green-500 text-white px-8 py-4 rounded-lg shadow-lg animate-bounce">
            <div className="flex items-center space-x-2 text-lg font-semibold">
              <Icons.Sparkles size={24} />
              <span>Great job! Keep it up! 🎉</span>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-green-500 p-2 rounded-full">
                <Icons.Leaf size={24} className="text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Ecolify</h1>
                <p className="text-sm text-gray-600">Building a sustainable future, one habit at a time</p>
              </div>
            </div>
            
            {/* Quick Stats */}
            <div className="hidden md:flex items-center space-x-6 text-sm">
              <div className="text-center">
                <div className="font-semibold text-green-600">{todayCompleted}/{selectedHabitsCount}</div>
                <div className="text-gray-600">Today</div>
              </div>
              <div className="text-center">
                <div className="font-semibold text-amber-600">{progress.totalPoints}</div>
                <div className="text-gray-600">Points</div>
              </div>
              <div className="text-center">
                <div className="font-semibold text-orange-600">{progress.currentStreak}</div>
                <div className="text-gray-600">Streak</div>
              </div>
              <button
                onClick={signOut}
                className="text-gray-500 hover:text-gray-700 text-sm"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex space-x-8 overflow-x-auto">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap transition-colors duration-200 ${
                  activeTab === tab.id
                    ? 'border-green-500 text-green-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                {getIcon(tab.icon)}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {activeTab === 'tracker' && (
          <DailyTracker
            habits={habits}
            onToggleCompletion={toggleHabitCompletion}
          />
        )}
        
        {activeTab === 'habits' && (
          <HabitSelector
            habits={habits}
            onToggleHabit={toggleHabitSelection}
          />
        )}
        
        {activeTab === 'progress' && (
          <ProgressStats progress={progress} />
        )}
        
        {activeTab === 'badge' && (
          <BadgeGenerator
            progress={progress}
            onDownload={handleBadgeDownload}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Icons.Heart size={20} className="text-green-400" />
            <span>Made with love for the planet</span>
          </div>
          <p className="text-gray-400 text-sm">
            Every small action counts. Together, we can make a difference for our environment.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;