import { UserProgress, UserHabit } from '../types/habits';
import { defaultHabits } from '../data/defaultHabits';

const STORAGE_KEY = 'ecolify-habit-tracker';

export const loadUserProgress = (): UserProgress => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return {
        ...parsed,
        habits: parsed.habits || defaultHabits.map(habit => ({
          ...habit,
          isSelected: false,
          completedDates: [],
          currentStreak: 0,
          bestStreak: 0
        }))
      };
    }
  } catch (error) {
    console.error('Error loading user progress:', error);
  }
  
  return {
    totalPoints: 0,
    currentStreak: 0,
    bestStreak: 0,
    level: 1,
    dailyProgress: [],
    habits: defaultHabits.map(habit => ({
      ...habit,
      isSelected: false,
      completedDates: [],
      currentStreak: 0,
      bestStreak: 0
    }))
  };
};

export const saveUserProgress = (progress: UserProgress): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (error) {
    console.error('Error saving user progress:', error);
  }
};

export const getTodayString = (): string => {
  return new Date().toISOString().split('T')[0];
};

export const calculateLevel = (totalPoints: number): number => {
  return Math.floor(totalPoints / 100) + 1;
};

export const getPointsForNextLevel = (totalPoints: number): number => {
  const currentLevel = calculateLevel(totalPoints);
  return currentLevel * 100 - totalPoints;
};

export const calculateStreak = (completedDates: string[]): number => {
  if (completedDates.length === 0) return 0;
  
  const sortedDates = completedDates.sort().reverse();
  const today = getTodayString();
  
  let streak = 0;
  let currentDate = new Date(today);
  
  for (const dateString of sortedDates) {
    const date = new Date(dateString);
    const diffTime = currentDate.getTime() - date.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === streak) {
      streak++;
      currentDate = new Date(date);
    } else {
      break;
    }
  }
  
  return streak;
};