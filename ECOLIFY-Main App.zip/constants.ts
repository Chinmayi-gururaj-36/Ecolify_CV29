
import React from 'react';
import { Habit } from './types';
import { LeafIcon, ReusableCupIcon, LightbulbIcon, CycleIcon, PlantBasedIcon, CompostIcon } from './components/Icons';

export const INITIAL_HABITS: Habit[] = [
  {
    id: 1,
    name: "Use a Reusable Water Bottle",
    icon: React.createElement(ReusableCupIcon),
    impact: { plasticAvoided: 1 },
    description: "Avoid single-use plastic bottles.",
    streak: 0,
    lastTracked: null,
  },
  {
    id: 2,
    name: "Shorter Showers (5 min)",
    icon: React.createElement(LeafIcon),
    impact: { waterSaved: 38 },
    description: "Conserve water with every wash.",
    streak: 0,
    lastTracked: null,
  },
  {
    id: 3,
    name: "Turn Off Unused Lights",
    icon: React.createElement(LightbulbIcon),
    impact: { co2Reduced: 0.1 },
    description: "Save energy when you leave a room.",
    streak: 0,
    lastTracked: null,
  },
  {
    id: 4,
    name: "Bike or Walk Instead of Drive",
    icon: React.createElement(CycleIcon),
    impact: { co2Reduced: 0.4 },
    description: "Reduce your carbon footprint on short trips.",
    streak: 0,
    lastTracked: null,
  },
  {
    id: 5,
    name: "Eat a Plant-Based Meal",
    icon: React.createElement(PlantBasedIcon),
    impact: { co2Reduced: 1.5, waterSaved: 200 },
    description: "Lower emissions with a veggie-powered dish.",
    streak: 0,
    lastTracked: null,
  },
  {
    id: 6,
    name: "Compost Food Scraps",
    icon: React.createElement(CompostIcon),
    impact: { co2Reduced: 0.2 },
    description: "Turn food waste into nutrient-rich soil.",
    streak: 0,
    lastTracked: null,
  }
];
