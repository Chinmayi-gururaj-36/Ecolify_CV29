
import { GoogleGenAI, Type } from "@google/genai";
import type { SuggestedHabit } from '../types';

if (!process.env.API_KEY) {
  // In a real app, you'd want to handle this more gracefully.
  // For this example, we'll log an error to the console.
  console.error("API_KEY environment variable not set. Gemini features will not work.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

/**
 * Extracts a JSON string from a text that might be wrapped in markdown fences.
 * @param text The raw text from the API response.
 * @returns A clean JSON string.
 */
const extractJson = (text: string): string => {
  const match = text.match(/```(json)?\s*([\s\S]*?)\s*```/);
  if (match && match[2]) {
    return match[2].trim();
  }
  return text.trim();
};


export const getHabitSuggestions = async (lifestyleDescription: string): Promise<SuggestedHabit[]> => {
  if (!process.env.API_KEY) {
    throw new Error("Gemini API key is not configured.");
  }
  
  const prompt = `You are an expert in sustainable living and environmental science. Based on the following user's lifestyle, suggest three simple, creative, and actionable eco-friendly habits. For each habit, provide a short, catchy name, a one-sentence description of how to perform it, and the primary impact category from these options: 'Reduces Plastic', 'Saves Water', 'Lowers Carbon Footprint', 'Reduces Waste', 'Conserves Energy'.

User's lifestyle: "${lifestyleDescription}"

Return the response as a JSON array that strictly follows the provided schema.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              habitName: {
                type: Type.STRING,
                description: "A short, catchy name for the habit.",
              },
              description: {
                type: Type.STRING,
                description: "A one-sentence explanation of the habit.",
              },
              impactCategory: {
                type: Type.STRING,
                description: "The primary positive environmental impact.",
              },
            },
            required: ["habitName", "description", "impactCategory"],
          },
        },
      },
    });

    const jsonText = extractJson(response.text);
    const suggestions: SuggestedHabit[] = JSON.parse(jsonText);
    return suggestions;
    
  } catch (error) {
    console.error("Error generating habit suggestions:", error);
    throw new Error("Failed to get suggestions from AI. Please try again.");
  }
};
