
import type { Stats, Habit } from '../types';
import { INITIAL_HABITS } from '../constants';

// --- Helper Functions ---
const getISODate = (date: Date): string => date.toISOString().split('T')[0];

const isYesterday = (today: Date, otherDate: Date): boolean => {
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    return getISODate(yesterday) === getISODate(otherDate);
};

const getWeek = (date: Date): number => {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(),0,1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1)/7);
};


// --- In-memory "Database" ---
let communityStats: Stats = {
  waterSaved: 125430,
  co2Reduced: 4587,
  plasticAvoided: 89123,
};

let availableHabits: Habit[] = [...INITIAL_HABITS];
let weeklyProgress = {
  count: 3,
  week: getWeek(new Date()),
};

// --- API Functions ---
const checkAndResetWeeklyProgress = () => {
    const currentWeek = getWeek(new Date());
    if (weeklyProgress.week !== currentWeek) {
        weeklyProgress.count = 0;
        weeklyProgress.week = currentWeek;
    }
};

export const getInitialData = (): Promise<{ stats: Stats, habits: Habit[], weeklyProgress: number }> => {
    checkAndResetWeeklyProgress();
    return new Promise(resolve => {
        setTimeout(() => {
            resolve({
                stats: { ...communityStats },
                habits: [...availableHabits],
                weeklyProgress: weeklyProgress.count
            });
        }, 500);
    });
};

export const trackHabit = (habitId: number): Promise<{ updatedStats: Stats, updatedHabits: Habit[], newWeeklyProgress: number, habitJustTracked: boolean }> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      checkAndResetWeeklyProgress();
      const habit = availableHabits.find(h => h.id === habitId);
      if (!habit) {
        return reject(new Error("Habit not found"));
      }

      const today = new Date();
      const todayStr = getISODate(today);
      let habitJustTracked = false;

      // Only update if the habit hasn't been tracked today
      if (habit.lastTracked !== todayStr) {
          habitJustTracked = true;
          // Update streak
          if (habit.lastTracked && isYesterday(today, new Date(habit.lastTracked))) {
              habit.streak += 1;
          } else {
              habit.streak = 1;
          }
          habit.lastTracked = todayStr;

          // Update community stats
          communityStats.waterSaved += habit.impact.waterSaved || 0;
          communityStats.co2Reduced += habit.impact.co2Reduced || 0;
          communityStats.plasticAvoided += habit.impact.plasticAvoided || 0;

          // Update weekly progress
          weeklyProgress.count += 1;
      }
      
      resolve({ 
          updatedStats: { ...communityStats },
          updatedHabits: [...availableHabits],
          newWeeklyProgress: weeklyProgress.count,
          habitJustTracked
      });
    }, 200);
  });
};
