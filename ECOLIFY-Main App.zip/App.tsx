
import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import HowItWorks from './components/HowItWorks';
import Features from './components/Features';
import Impact from './components/Impact';
import Community from './components/Community';
import Footer from './components/Footer';
import HabitSuggester from './components/HabitSuggester';
import WeeklyProgress from './components/WeeklyProgress';
import { getInitialData, trackHabit as apiTrackHabit } from './services/mockApiService';
import type { Stats, Habit } from './types';

const WEEKLY_GOAL = 7;

function App() {
  const [stats, setStats] = useState<Stats>({ waterSaved: 0, co2Reduced: 0, plasticAvoided: 0 });
  const [habits, setHabits] = useState<Habit[]>([]);
  const [isSuggesterOpen, setIsSuggesterOpen] = useState(false);
  const [notification, setNotification] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  const [weeklyProgress, setWeeklyProgress] = useState(0);

  useEffect(() => {
    async function fetchData() {
      try {
        const { stats, habits, weeklyProgress } = await getInitialData();
        setStats(stats);
        setHabits(habits);
        setWeeklyProgress(weeklyProgress);
      } catch (error) {
        console.error("Failed to fetch initial data:", error);
        showNotification("Error: Could not load app data.", "error");
      }
    }
    fetchData();
  }, []);

  const showNotification = (message: string, type: 'success' | 'error' = 'success') => {
    setNotification({ message, type });
    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  const handleTrackHabit = useCallback(async (habitId: number) => {
    try {
      const { updatedStats, updatedHabits, newWeeklyProgress, habitJustTracked } = await apiTrackHabit(habitId);
      setStats(updatedStats);
      setHabits(updatedHabits);
      setWeeklyProgress(newWeeklyProgress);

      if (habitJustTracked) {
        showNotification("Habit tracked! Your impact has been updated.", "success");
      } else {
        showNotification("You've already tracked this habit today!", "error");
      }

    } catch (error) {
      console.error("Error tracking habit:", error);
      showNotification("Error: Could not track habit.", "error");
    }
  }, []);
  
  const openSuggester = () => setIsSuggesterOpen(true);
  const closeSuggester = () => setIsSuggesterOpen(false);

  return (
    <div className="flex flex-col min-h-screen font-sans">
      <Header onStart={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })} />
      <main className="flex-grow">
        <Hero onJoin={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })} onSuggest={openSuggester} />
        <HowItWorks />
        <WeeklyProgress progress={weeklyProgress} goal={WEEKLY_GOAL} />
        <Features habits={habits} onTrackHabit={handleTrackHabit} />
        <Impact stats={stats} />
        <Community />
      </main>
      <Footer />
      {isSuggesterOpen && <HabitSuggester onClose={closeSuggester} />}
      {notification && (
        <div className={`fixed bottom-5 right-5 text-white py-2 px-4 rounded-lg shadow-lg animate-fade-in-out ${notification.type === 'success' ? 'bg-green-600' : 'bg-red-600'}`}>
          {notification.message}
        </div>
      )}
    </div>
  );
}

export default App;