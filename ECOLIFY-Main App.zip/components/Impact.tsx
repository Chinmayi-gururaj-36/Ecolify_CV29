import React, { useState, useEffect } from 'react';
import type { Stats } from '../types';

interface AnimatedCounterProps {
  value: number;
}

const AnimatedCounter: React.FC<AnimatedCounterProps> = ({ value }) => {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    let start = displayValue;
    const end = value;
    if (start === end) return;
    
    const duration = 1500; // ms
    const range = end - start;
    let startTime: number | null = null;

    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const current = Math.floor(progress * range + start);
      setDisplayValue(current);
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };
    
    requestAnimationFrame(step);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  return <span className="stat-number">{displayValue.toLocaleString()}</span>;
};


interface StatDisplayProps {
  value: number;
  label: string;
}

const StatDisplay: React.FC<StatDisplayProps> = ({ value, label }) => (
  <div className="text-center flex-1 min-w-[200px] p-4">
    <div className="text-4xl sm:text-5xl font-bold">
      <AnimatedCounter value={value} />
    </div>
    <div className="text-lg">{label}</div>
  </div>
);

interface ImpactProps {
  stats: Stats;
}

const Impact: React.FC<ImpactProps> = ({ stats }) => {
  return (
    <section 
      id="impact" 
      className="bg-primary text-white py-16 sm:py-24 px-4 animate-section animation-delay-200"
      style={{
        backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.05) 1px, transparent 1px)',
        backgroundSize: '1rem 1rem'
      }}
    >
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-center text-white mb-12">
          The Difference We're Making Together
        </h2>
        <div className="flex flex-wrap justify-center items-center gap-8">
          <StatDisplay value={stats.waterSaved} label="Litres of Water Saved" />
          <StatDisplay value={stats.co2Reduced} label="Kg of CO2 Reduced" />
          <StatDisplay value={stats.plasticAvoided} label="Pieces of Plastic Avoided" />
        </div>
      </div>
    </section>
  );
};

export default Impact;