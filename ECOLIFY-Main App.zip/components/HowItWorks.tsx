import React from 'react';

interface StepProps {
  number: number;
  title: string;
  children: React.ReactNode;
}

const Step = ({ number, title, children }: StepProps) => (
  <div className="text-center p-6 flex-1 min-w-[280px]">
     <div className="w-16 h-16 bg-primary-light text-primary-dark flex items-center justify-center rounded-full mx-auto mb-4 font-bold text-2xl shadow-md">
      {number}
    </div>
    <h3 className="text-xl font-semibold text-primary-dark mb-2">{title}</h3>
    <p className="text-neutral">{children}</p>
  </div>
);

const HowItWorks = () => {
  return (
    <section className="bg-neutral-light py-16 sm:py-24 px-4 animate-section animation-delay-200">
      <h2 className="text-3xl sm:text-4xl font-bold text-center text-primary-dark mb-12">
        Your Journey to a Greener Lifestyle
      </h2>
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-center gap-8">
        <Step number={1} title="Choose Your Habits">
          Select from a list of impactful green habits or get AI-powered suggestions tailored to your lifestyle.
        </Step>
        <Step number={2} title="Track Your Progress">
          Simply check off your habits each day. Our tracker makes it satisfying to see your consistency and build momentum.
        </Step>
        <Step number={3} title="See Your Impact Grow">
          Visualize your positive contribution as we estimate the water, CO2, and plastic you've saved with the community.
        </Step>
      </div>
    </section>
  );
};

export default HowItWorks;