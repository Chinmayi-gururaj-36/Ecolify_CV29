
import React, { useState } from 'react';
import { getHabitSuggestions } from '../services/geminiService';
import type { SuggestedHabit } from '../types';

interface HabitSuggesterProps {
  onClose: () => void;
}

const LoadingSpinner = () => (
  <div className="flex justify-center items-center p-4">
    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
  </div>
);

const SuggestionCard: React.FC<{ suggestion: SuggestedHabit }> = ({ suggestion }) => (
    <div className="bg-primary-light p-4 rounded-lg border border-primary/20">
        <h4 className="font-bold text-primary-dark">{suggestion.habitName}</h4>
        <p className="text-sm text-neutral mt-1">{suggestion.description}</p>
        <p className="text-xs font-semibold text-primary mt-2 bg-primary-light inline-block px-2 py-1 rounded-full">{suggestion.impactCategory}</p>
    </div>
);

const HabitSuggester: React.FC<HabitSuggesterProps> = ({ onClose }) => {
  const [lifestyle, setLifestyle] = useState('');
  const [suggestions, setSuggestions] = useState<SuggestedHabit[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lifestyle.trim()) {
      setError("Please describe your lifestyle.");
      return;
    }
    setIsLoading(true);
    setError(null);
    setSuggestions([]);

    try {
      const result = await getHabitSuggestions(lifestyle);
      setSuggestions(result);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl shadow-2xl p-6 sm:p-8 w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-primary-dark">Personalized Habit AI</h2>
          <button onClick={onClose} className="text-neutral-dark hover:text-red-500 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <p className="text-neutral mb-6">Describe your daily routine or hobbies, and our AI will suggest custom eco-friendly habits for you. <em className="text-sm">(e.g., "I work from home, drink lots of coffee, and have a small balcony.")</em></p>
        
        <form onSubmit={handleSubmit}>
          <textarea
            value={lifestyle}
            onChange={(e) => setLifestyle(e.target.value)}
            placeholder="Tell us about your lifestyle..."
            className="w-full p-3 border-2 border-gray-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary transition mb-4"
            rows={4}
            disabled={isLoading}
          />
          <button type="submit" disabled={isLoading} className="w-full bg-primary text-white py-3 px-6 rounded-full font-bold hover:bg-primary-dark transition-all disabled:bg-gray-400 disabled:cursor-not-allowed">
            {isLoading ? 'Thinking...' : 'Generate Suggestions'}
          </button>
        </form>

        {isLoading && <LoadingSpinner />}
        {error && <p className="text-red-500 text-center mt-4">{error}</p>}
        
        {suggestions.length > 0 && (
          <div className="mt-8">
            <h3 className="text-xl font-bold text-primary-dark mb-4">Here are your suggestions:</h3>
            <div className="space-y-4">
                {suggestions.map((s, index) => <SuggestionCard key={index} suggestion={s} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default HabitSuggester;
