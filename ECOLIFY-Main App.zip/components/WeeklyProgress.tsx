import React from 'react';
import { TreeStage1Icon, TreeStage2Icon, TreeStage3Icon, TreeStage4Icon, TreeStage5Icon } from './Icons';

interface WeeklyProgressProps {
    progress: number;
    goal: number;
}

const getTreeStage = (progress: number, goal: number): React.ReactElement => {
    const percentage = goal > 0 ? (progress / goal) : 0;
    const size = 120; // Base size for the icons

    if (percentage < 0.25) { // 0-24%
        return <TreeStage1Icon size={size} />;
    }
    if (percentage < 0.50) { // 25-49%
        return <TreeStage2Icon size={size} />;
    }
    if (percentage < 1) { // 50-99%
        return <TreeStage3Icon size={size} />;
    }
    if (percentage < 1.5) { // 100-149% (Goal met)
        return <TreeStage4Icon size={size} />;
    }
    // 150%+ (Exceeding goal)
    return <TreeStage5Icon size={size} />;
};

const getCompletionMessage = (progress: number, goal: number): string => {
    if (goal <= 0) return "Set a goal to get started!";
    const percentage = progress / goal;

    if (percentage === 0) {
        return "Let's grow! Track your first habit to plant your sapling.";
    }
    if (percentage < 1) {
        return "Great start! Keep nurturing your tree with daily habits.";
    }
    if (percentage < 1.5) {
        return "Amazing! You've grown a mature tree this week!";
    }
    return "Incredible! Your tree is thriving thanks to your dedication!";
};


const WeeklyProgress: React.FC<WeeklyProgressProps> = ({ progress, goal }) => {
    const percentage = goal > 0 ? Math.min((progress / goal) * 100, 100) : 0;
    const TreeComponent = getTreeStage(progress, goal);
    const message = getCompletionMessage(progress, goal);

    return (
        <section className="pt-12 pb-4 px-4 animate-section animation-delay-400">
            <div className="max-w-4xl mx-auto bg-white p-6 sm:p-8 rounded-2xl border-2 border-primary-light shadow-lg">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-6 sm:gap-10">
                    {/* Tree Visualization */}
                    <div className="flex-shrink-0 w-[120px] h-[120px] flex items-center justify-center">
                         {TreeComponent}
                    </div>

                    {/* Progress Details */}
                    <div className="w-full text-center sm:text-left">
                        <h3 className="text-xl sm:text-2xl font-bold text-primary-dark">Your Weekly Growth</h3>
                         <p className="text-neutral mt-1 mb-4">{message}</p>
                        
                        <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden mb-2 shadow-inner">
                            <div
                                className="bg-gradient-to-r from-green-400 to-primary h-4 rounded-full transition-all duration-500 ease-out"
                                style={{ width: `${percentage}%` }}
                            ></div>
                        </div>
                        <p className="text-sm font-semibold text-primary-dark text-right">{progress} / {goal} Habits Tracked</p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default WeeklyProgress;