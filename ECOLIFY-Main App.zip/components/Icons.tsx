
import React from 'react';

const iconProps = {
  className: "w-12 h-12 text-primary mb-4 mx-auto",
  strokeWidth: "1.5",
};

export const LeafIcon = () => (
  <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
  </svg>
);

export const ReusableCupIcon = () => (
  <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
  </svg>
);

export const LightbulbIcon = () => (
  <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
  </svg>
);

export const CycleIcon = () => (
  <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v.01M12 6v-1h4v1h-4zm-4 6v-1h4v1h-4zm-2 4v-1h12v1H6zM4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
  </svg>
);

export const PlantBasedIcon = () => (
  <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
  </svg>
);

export const CompostIcon = () => (
  <svg {...iconProps} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h5V4H4zm0 11h5v5H4v-5zm11-11h5v5h-5V4zm0 11h5v5h-5v-5z" />
  </svg>
);

export const FireIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
        <path fillRule="evenodd" d="M10 2a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0110 2zM5.505 4.43a.75.75 0 01.968-.432l1.29 1.29a.75.75 0 01-1.06 1.06l-1.29-1.29a.75.75 0 01.092-1.628zM14.495 4.43a.75.75 0 01.092 1.628l-1.29 1.29a.75.75 0 01-1.06-1.06l1.29-1.29a.75.75 0 01.968.432zM3 9.75a.75.75 0 01.75-.75h1.5a.75.75 0 010 1.5h-1.5A.75.75 0 013 9.75zM15 9.75a.75.75 0 01.75-.75h1.5a.75.75 0 010 1.5h-1.5A.75.75 0 0115 9.75zM6.565 13.91a.75.75 0 011.06-1.06l1.29 1.29a.75.75 0 01-1.06 1.06l-1.29-1.29a.75.75 0 010-1.06zM13.435 13.91a.75.75 0 010 1.06l-1.29 1.29a.75.75 0 01-1.06-1.06l1.29-1.29a.75.75 0 011.06 0zM10 16a.75.75 0 01.75.75v1.5a.75.75 0 01-1.5 0v-1.5A.75.75 0 0110 16z" clipRule="evenodd" />
        <path d="M5.21 8.24a.75.75 0 011.06 0l4.5 4.5a.75.75 0 01-1.06 1.06l-4.5-4.5a.75.75 0 010-1.06zM14.79 8.24a.75.75 0 010 1.06l-4.5 4.5a.75.75 0 01-1.06-1.06l4.5-4.5a.75.75 0 011.06 0z"/>
    </svg>
);


// --- NEW Tree Growth Icons ---
const treeIconProps = {
  className: "transition-all duration-700 ease-in-out",
};

// Stage 1: Sapling
export const TreeStage1Icon = ({ size = 120 }) => (
  <svg {...treeIconProps} width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
    <path d="M32 54V26" stroke="#8B572A" fill="none" strokeWidth="3" strokeLinecap="round"/>
    <path d="M32 34c0-4.418-4-8-8-8s-6 3.582-6 8" stroke="#2E7D32" fill="none" strokeWidth="3" strokeLinecap="round"/>
    <path d="M32 34c0-4.418 4-8 8-8s6 3.582 6 8" stroke="#2E7D32" fill="none" strokeWidth="3" strokeLinecap="round"/>
  </svg>
);

// Stage 2: Young Tree
export const TreeStage2Icon = ({ size = 120 }) => (
  <svg {...treeIconProps} width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
    <path d="M32 56V24" stroke="#8B572A" fill="none" strokeWidth="4" strokeLinecap="round"/>
    <path d="M32 36L24 30" stroke="#8B572A" fill="none" strokeWidth="3.5" strokeLinecap="round"/>
    <path d="M32 36L40 30" stroke="#8B572A" fill="none" strokeWidth="3.5" strokeLinecap="round"/>
    <circle cx="22" cy="24" r="7" fill="#4CAF50"/>
    <circle cx="42" cy="24" r="7" fill="#4CAF50"/>
    <circle cx="32" cy="18" r="8" fill="#4CAF50"/>
  </svg>
);

// Stage 3: Growing Tree
export const TreeStage3Icon = ({ size = 120 }) => (
  <svg {...treeIconProps} width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
    <path d="M32 58V22" stroke="#8B572A" fill="none" strokeWidth="5" strokeLinecap="round"/>
    <path d="M32 40L20 32" stroke="#8B572A" fill="none" strokeWidth="4.5" strokeLinecap="round"/>
    <path d="M32 40L44 32" stroke="#8B572A" fill="none" strokeWidth="4.5" strokeLinecap="round"/>
    <path d="M32 30L26 25" stroke="#8B572A" fill="none" strokeWidth="4" strokeLinecap="round"/>
    <circle cx="32" cy="16" r="13" fill="#4CAF50"/>
    <circle cx="18" cy="28" r="9" fill="#66BB6A"/>
    <circle cx="46" cy="28" r="9" fill="#66BB6A"/>
  </svg>
);

// Stage 4: Mature Tree
export const TreeStage4Icon = ({ size = 120 }) => (
  <svg {...treeIconProps} width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
    <path d="M32 60V20" stroke="#8B572A" fill="none" strokeWidth="6" strokeLinecap="round"/>
    <path d="M32 44L18 34" stroke="#8B572A" fill="none" strokeWidth="5" strokeLinecap="round"/>
    <path d="M32 44L46 34" stroke="#8B572A" fill="none" strokeWidth="5" strokeLinecap="round"/>
    <path d="M24 28L18 22" stroke="#8B572A" fill="none" strokeWidth="4" strokeLinecap="round"/>
    <path d="M40 28L46 22" stroke="#8B572A" fill="none" strokeWidth="4" strokeLinecap="round"/>
    <circle cx="32" cy="15" r="15" fill="#2E7D32"/>
    <circle cx="16" cy="26" r="11" fill="#4CAF50"/>
    <circle cx="48" cy="26" r="11" fill="#4CAF50"/>
  </svg>
);

// Stage 5: Thriving Tree
export const TreeStage5Icon = ({ size = 120 }) => (
  <svg {...treeIconProps} width={size} height={size} viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg">
    <path d="M32 60V20" stroke="#6D4C41" fill="none" strokeWidth="7" strokeLinecap="round"/>
    <path d="M32 44L18 34" stroke="#6D4C41" fill="none" strokeWidth="6" strokeLinecap="round"/>
    <path d="M32 44L46 34" stroke="#6D4C41" fill="none" strokeWidth="6" strokeLinecap="round"/>
    <path d="M24 28L18 22" stroke="#6D4C41" fill="none" strokeWidth="5" strokeLinecap="round"/>
    <path d="M40 28L46 22" stroke="#6D4C41" fill="none" strokeWidth="5" strokeLinecap="round"/>
    <circle cx="32" cy="15" r="15" fill="#1B5E20"/>
    <circle cx="16" cy="26" r="11" fill="#2E7D32"/>
    <circle cx="48" cy="26" r="11" fill="#2E7D32"/>
    {/* Fruits/Flowers */}
    <circle cx="35" cy="8" r="1.5" fill="#FFEB3B"/>
    <circle cx="28" cy="12" r="1.5" fill="#FFEB3B"/>
    <circle cx="15" cy="22" r="1.5" fill="#FFEB3B"/>
    <circle cx="49" cy="22" r="1.5" fill="#FFEB3B"/>
    <circle cx="45" cy="30" r="1.5" fill="#FFEB3B"/>
  </svg>
);
