import React from 'react';

interface HeroProps {
  onJoin: () => void;
  onSuggest: () => void;
}

const Hero: React.FC<HeroProps> = ({ onJoin, onSuggest }) => {
  return (
    <section className="bg-gradient-to-b from-primary-light via-neutral-light to-neutral-light text-center py-20 sm:py-28 px-4 animate-section">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl sm:text-6xl font-bold text-primary-dark leading-tight mb-4">
          Small Habits, Big Impact.
        </h1>
        <p className="text-lg sm:text-xl text-neutral mb-8 max-w-2xl mx-auto">
          The simple way to build sustainable habits and track your positive impact on the planet. Join a community making a difference, one green choice at a time.
        </p>
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
          <button onClick={onJoin} className="bg-primary text-white py-3 px-8 rounded-full font-bold text-lg shadow-lg hover:shadow-xl hover:bg-primary-dark transition-all transform hover:scale-105 w-full sm:w-auto">
            Join the Movement
          </button>
           <button onClick={onSuggest} className="bg-white text-primary border-2 border-primary py-3 px-8 rounded-full font-bold text-lg shadow-lg hover:shadow-xl hover:bg-primary-light transition-all transform hover:scale-105 w-full sm:w-auto">
            Get AI Suggestions
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;