import React from 'react';

const Community = () => {
  return (
    <section id="community" className="bg-neutral-light py-16 sm:py-24 px-4 animate-section animation-delay-400">
      <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-primary-dark mb-4">
          Join a Community of Changemakers
        </h2>
        <p className="text-lg text-neutral mb-10">
          You're not alone. Connect with others, share tips, and take on fun challenges together.
        </p>
        <div className="bg-white p-8 sm:p-10 rounded-2xl border-2 border-primary-light shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-300">
          <h4 className="text-sm font-semibold uppercase text-primary tracking-widest">This Month's Challenge</h4>
          <h3 className="text-3xl font-bold text-primary-dark my-3">No Single-Use Plastic Week</h3>
          <p className="text-neutral mb-6">
            Join thousands of others and see how much waste we can prevent as a community!
          </p>
          <a href="#" className="bg-primary text-white py-3 px-8 rounded-full font-bold text-lg hover:bg-primary-dark transition-colors inline-block shadow-lg hover:shadow-xl">
            I'm In!
          </a>
        </div>
      </div>
    </section>
  );
};

export default Community;