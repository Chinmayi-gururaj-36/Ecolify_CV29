import React from 'react';
import type { Habit } from '../types';
import { FireIcon } from './Icons';

interface HabitCardProps {
  habit: Habit;
  onTrack: (id: number) => void;
}

const HabitCard: React.FC<HabitCardProps> = ({ habit, onTrack }) => {
  return (
    <div className="relative bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 flex flex-col text-center border border-transparent hover:border-primary/20">
      {habit.streak > 0 && (
        <div className="absolute top-3 right-3 bg-amber-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1 shadow-md">
          <FireIcon />
          <span>{habit.streak} day{habit.streak > 1 ? 's' : ''}</span>
        </div>
      )}
      {habit.icon}
      <h4 className="text-lg font-bold text-neutral-dark mb-2">{habit.name}</h4>
      <p className="text-neutral text-sm mb-4 flex-grow">{habit.description}</p>
      <button 
        onClick={() => onTrack(habit.id)}
        className="mt-auto bg-primary-light text-primary-dark font-semibold py-2 px-4 rounded-full hover:bg-primary hover:text-white transition-colors"
      >
        Track It!
      </button>
    </div>
  );
};

interface FeaturesProps {
  habits: Habit[];
  onTrackHabit: (id: number) => void;
}

const Features: React.FC<FeaturesProps> = ({ habits, onTrackHabit }) => {
  return (
    <section id="features" className="bg-primary-light py-16 sm:py-24 px-4 animate-section animation-delay-600">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-3xl sm:text-4xl font-bold text-center text-primary-dark mb-12">
          Build Lasting Green Habits
        </h2>
        {habits.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
            {habits.map(habit => (
              <HabitCard key={habit.id} habit={habit} onTrack={onTrackHabit} />
            ))}
          </div>
        ) : (
          <div className="text-center text-neutral">
            <p>Loading habits...</p>
          </div>
        )}
      </div>
    </section>
  );
};

export default Features;