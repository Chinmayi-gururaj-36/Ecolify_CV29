
import React from 'react';

interface HeaderProps {
  onStart: () => void;
}

const Header: React.FC<HeaderProps> = ({ onStart }) => {
  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
      <nav className="flex justify-between items-center max-w-6xl mx-auto p-4">
        <div className="text-2xl font-bold text-primary-dark flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-primary" viewBox="0 0 20 20" fill="currentColor">
            <path d="M17.293 4.293a1 1 0 011.414 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L10 11.586l7.293-7.293z" />
          </svg>
          Ecolify
        </div>
        <ul className="hidden md:flex list-none gap-8 items-center">
          <li><a href="#features" className="text-neutral-dark font-semibold hover:text-primary transition-colors">Features</a></li>
          <li><a href="#impact" className="text-neutral-dark font-semibold hover:text-primary transition-colors">Your Impact</a></li>
          <li><a href="#community" className="text-neutral-dark font-semibold hover:text-primary transition-colors">Community</a></li>
        </ul>
        <button onClick={onStart} className="bg-primary text-white py-2 px-5 rounded-full font-semibold hover:bg-primary-dark transition-all transform hover:scale-105">
          Start Tracking
        </button>
      </nav>
    </header>
  );
};

export default Header;
