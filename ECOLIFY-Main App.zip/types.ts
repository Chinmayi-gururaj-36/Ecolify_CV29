import type { ReactNode } from 'react';

export interface Stats {
  waterSaved: number;
  co2Reduced: number;
  plasticAvoided: number;
}

export interface Habit {
  id: number;
  name: string;
  icon: ReactNode;
  impact: Partial<Stats>;
  description: string;
  streak: number;
  lastTracked: string | null;
}

export interface SuggestedHabit {
  habitName: string;
  description: string;
  impactCategory: string;
}